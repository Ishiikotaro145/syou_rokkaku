﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wind : MonoBehaviour {

	public List<GameObject> pWindPrefab;
	List<Vector3> LeafPos = new List<Vector3>();
	List<Vector3> LeafVec = new List<Vector3>();
	List<bool> isBlowList = new List<bool> ();


	Vector3 moveVec = new Vector3(0.0f,1.0f,0.0f);
	int LeafTimer = 0;
	int LeafIndex = 0;

	// Use this for initialization
	void Start () 
	{
		moveVec = Quaternion.Euler (0,0,transform.localEulerAngles.z) * moveVec;

		//木の葉　初期座標
		for(int i = 0;i < pWindPrefab.Count;i++)
		{
			LeafPos.Add (pWindPrefab[i].transform.position);
			isBlowList.Add (false);
			LeafVec.Add (Quaternion.Euler (0,0,transform.localEulerAngles.z) * moveVec);
		}
	}
	
	// Update is called once per frame
	void Update () 
	{

		//
		BlowAnimation();

	}


	void BlowAnimation()
	{
		LeafTimer++;
		if (LeafTimer % 5 == 0)
		{
			if (LeafIndex < isBlowList.Count) 
			{
				isBlowList[LeafIndex] = true;
				LeafIndex++;				
			}
		}


		for(int bCnt = 0;bCnt < pWindPrefab.Count;bCnt++)
		{
			if (isBlowList[bCnt] == true) 
			{
				pWindPrefab [bCnt].transform.position += (LeafVec[bCnt]);
				LeafVec [bCnt] *= 0.8f;
				//木の葉座標リセット
				//if((pWindPrefab[bCnt].transform.position - transform.position).magnitude > 5.0f)
				if((LeafVec[bCnt].magnitude < 0.001f))
				{
					//pWindPrefab [bCnt].transform.position = new Vector3 (LeafPos[bCnt].x,LeafPos[bCnt].y,LeafPos[bCnt].z);
					pWindPrefab [bCnt].transform.position = new Vector3 (transform.position.x,transform.position.y,transform.position.z);
					LeafVec [bCnt] = Quaternion.Euler (0,0,transform.localEulerAngles.z) * moveVec;

				}
			}

			//pWindPrefab [bCnt].transform.rotation = Quaternion.Euler (0,0,10.0f);
		}
		//Debug.Log (LeafVec[0]);
	}


	void OnTriggerStay2D(Collider2D _other)
	{
		//主人公が風当たり判定に接触した時の処理
		if (_other.transform.tag == "Player")
		{
			//ボール側のスクリプトにアクセス
			Ball ballScript = _other.gameObject.GetComponent<Ball>();




			ballScript.AddVec (moveVec);
			//ballScript.DivVecX ();

		}
	}
}
