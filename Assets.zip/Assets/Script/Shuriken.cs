﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shuriken : EnemyBase {

	Vector3 shotVec = new Vector3();

	public void Init(Vector3 _ShotVec)
	{
		shotVec = _ShotVec;
	}


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		transform.position += new Vector3 (shotVec.x,shotVec.y,shotVec.z);
	}
}
