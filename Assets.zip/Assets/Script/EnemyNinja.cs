﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyNinja : EnemyBase {

	public GameObject pAttackPrefab;
	public Vector3 pShotVec;


	public int attackInterval;
	int nowInterval = 0;

	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		nowInterval++;
		if (nowInterval >= attackInterval) 
		{
			nowInterval = 0;
			GameObject attackObject = (GameObject)Instantiate 
				(
					pAttackPrefab,
					transform.position,
					Quaternion.identity
				);

			Shuriken shuriken = attackObject.GetComponent<Shuriken>();

			if (shuriken != null) 
			{
				shuriken.Init (pShotVec);
			}
		}


	}
}
