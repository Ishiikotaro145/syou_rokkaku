﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventManager : SingletonBase<EventManager> {





	bool isBeginEvent = false;
	bool isStart = false;
	int TimerScroll = 0;

	public bool GetIsBeginEvent(){ return isBeginEvent; }




	void Awake()
	{
		if (this != GetInstance)
		{
			Destroy (this);
			return;
		}
		DontDestroyOnLoad (this.gameObject);
	}


	void Init()
	{
		isBeginEvent = false;
		isStart = false;
		TimerScroll = 0;
	}

	
	// Update is called once per frame
	void Update ()
	{



		//ゴールからスタート地点にスクロール

		GameObject goalObject = GameObject.Find ("Goal");
		if (goalObject != null)
		{
			if (isBeginEvent == false) 
			{
				Camera.main.transform.position = new Vector3 (goalObject.transform.position.x, goalObject.transform.position.y, -10.0f);
				isBeginEvent = true;

			}
			//Debug.Log ("ゴール取得");
		} 
		else 
		{
			//Debug.Log ("ゴール取得失敗！");
		}
		if (isBeginEvent == true) 
		{
			TimerScroll++;
			if (TimerScroll >= 60) 
			{
				//スクロール開始


				if (Camera.main.transform.position.y <= 0.01f && isStart == false)
				{
					Camera.main.transform.position = new Vector3(0.0f,0.0f,-10.0f);

					isStart = true;
				}
				else 
				{
					Camera.main.transform.position = new Vector3(0.0f,Camera.main.transform.position.y * 0.98f,-10.0f);
					//Camera.main.transform.position -= new Vector3(0.0f,0.15f,0.0f);
				}
			}
		}


		if (isStart == true)
		{
			
		}


		//Debug.Log ("EventManagerUpdate");

		//
	}




}
