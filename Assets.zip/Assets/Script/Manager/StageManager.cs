﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageManager : SingletonBase<StageManager>{


	public List<GameObject> pSingleStagePrefab;
	List<GameObject> singleStageList = new List<GameObject>();


	int nowStage = 1;

	void Awake()
	{
		if (this != GetInstance)
		{
			Destroy (this);
			return;
		}
		DontDestroyOnLoad (this.gameObject);
	}


	// Use this for initialization
	void Start () 
	{
		GameObject stageObject = (GameObject)Instantiate 
			(
				pSingleStagePrefab[0],
				new Vector3(transform.position.x,transform.position.y,transform.position.z),
				Quaternion.identity
			);
		singleStageList.Add (stageObject);


		Debug.Log ("Add");
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}



}
