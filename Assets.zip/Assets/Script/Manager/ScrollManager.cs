﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollManager : SingletonBase<ScrollManager> {

	float m_Scroll = 0.0f;

	public float GetScroll(){ return m_Scroll; }
	public void AddScroll(float _scroll){ m_Scroll = _scroll; }


	void Awake()
	{
		if (this != GetInstance)
		{
			Destroy (this);
			return;
		}
		DontDestroyOnLoad (this.gameObject);
	}


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
