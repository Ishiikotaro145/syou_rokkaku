﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trampoline : MonoBehaviour {

	bool isHit = false;
	Ball haveBallScript = null;
	Vector3 normalVec = new Vector3();	//法線 (入射角と反射角の計算に利用)

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (isHit == false)return;
		normalVec = Quaternion.Euler (0,0,transform.localEulerAngles.z) * Vector3.up;

	}


	void OnTriggerEnter2D(Collider2D _other)
	{
		Debug.Log ("トランポリンヒット");

		if (_other.transform.tag == "Player")
		{
			Ball ballScript = _other.gameObject.GetComponent<Ball> ();
			if (ballScript == null)return;
			ballScript.AddVec (Vector3.up * 20.0f);

			isHit = true;
			haveBallScript = ballScript;
		}

	}
}
